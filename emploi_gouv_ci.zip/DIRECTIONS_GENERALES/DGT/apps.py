from django.apps import AppConfig


class DgtConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DIRECTIONS_GENERALES.DGT'
