from django.apps import AppConfig


class DsstConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DIRECTIONS_GENERALES.DGT.dsst'
