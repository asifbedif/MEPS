from django.apps import AppConfig


class DitConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DIRECTIONS_GENERALES.DGT.dit'
