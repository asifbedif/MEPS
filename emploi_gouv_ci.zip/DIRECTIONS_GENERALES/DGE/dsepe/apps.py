from django.apps import AppConfig


class DsepeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DIRECTIONS_GENERALES.DGE.dsepe'
