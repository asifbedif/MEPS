from django.apps import AppConfig


class DpphConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DIRECTIONS_GENERALES.DGPS.dpph'
